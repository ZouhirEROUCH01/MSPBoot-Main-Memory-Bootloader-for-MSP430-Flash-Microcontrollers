/*
 * \file   main.c
 *
 * \brief  Main routine for the bootloader for F5529
 *
 */
/* --COPYRIGHT--,BSD
 * Copyright (c) 2017, Texas Instruments Incorporated
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * *  Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * *  Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 *
 * *  Neither the name of Texas Instruments Incorporated nor the names of
 *    its contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO,
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
 * PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS;
 * OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR
 * OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
 * EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 * --/COPYRIGHT--*/
//
//  Include files
//
#include <stdbool.h>
#include "msp430.h"
#include "TI_MSPBoot_Common.h"
#include "TI_MSPBoot_CI.h"
#include "TI_MSPBoot_AppMgr.h"

//
//  Local function prototypes
//
inline static void Clock_init(void);
inline static void HW_init(void);

/******************************************************************************
 *
 * @brief   Main function
 *  - Initializes the MCU
 *  - Selects whether to run application or bootloader
 *  - If bootloader:
 *      - Initializes the peripheral interface
 *      - Waits for a command
 *      - Sends the corresponding response
 *  - If application:
 *      - Jump to application
 *
 *  @note   USI interrupts are enabled after this function
 * @return  none
 *****************************************************************************/
int main_boot( void )
{
    // Stop watchdog timer to prevent time out reset
    WDTCTL = WDTPW + WDTHOLD;

   /* 
    * Important Note: 
    *   MSPBoot assumes that proper conditions are met when executing after reset. 
    *   It�s important to remark that DCO must not be changed until VCC>=VCC(min), 
    *   and a minimum of 2.2V is required for Flash Program/Erase operations.
    *   An optional software delay can be added for applications having a slow 
    *   voltage ramp-up or an external voltage supervisor is suggested
    *   
    */
    //  __delay_cycles(10000);  // Uncomment this line and adjust number of delay 
                                // cycles according to the application voltage ramp
    // Initialize MCU
    HW_init();

    Clock_init();

    // Validate the application and jump if needed
    if (TI_MSPBoot_AppMgr_ValidateApp() == true)
        TI_MSPBoot_APPMGR_JUMPTOAPP();

    TI_MSPBoot_CI_Init();      // Initialize the Communication Interface

#ifndef NDEBUG
    P1DIR |= BIT0;     // Used for debugging purposes to show entry to MSPBoot
    P4DIR |= BIT7;
    P1OUT |= BIT0;
    P4OUT |= BIT7;
#endif

    while(1)
    {
        // Poll PHY and Data Link interface for new packets
        TI_MSPBoot_CI_PHYDL_Poll();

        // If a new packet is detected, process it
        if (TI_MSPBoot_CI_Process() == RET_JUMP_TO_APP)
        {
            // If Packet indicates a jump to App
            TI_MSPBoot_AppMgr_JumpToApp();
        }
#ifdef NDEBUG
        // Feed the dog every (interval depends on MCLK freq)
        WATCHDOG_FEED();
#endif
    }


}

/******************************************************************************
 *
 * @brief   Initializes the MSP430 Clock
 *
 * @return  none
 *****************************************************************************/
inline static void Clock_init(void)
{
    // Set DCO = 8MHz
    UCSCTL3 &= ~(SELREF_7);     // Clear FLL Reference Select Bits
    UCSCTL3 |= SELREF_2;        // Set FLL Reference to REFOCLK
    UCSCTL4 |= SELA__VLOCLK;

    // Disable FLL
    __bis_SR_register(SCG0);

    UCSCTL2 &= ~(0x03FF);       // Clear FLLN Bits
    UCSCTL2 |= 249;             // Set DCO Multiplier for 8MHz
                                // (N + 1) * FLLRef = Fdco
                                // (249 + 1) * 32768 =~ 8MHz
    UCSCTL1 = DCORSEL_4;        // Set DCO Range Select

    // Re-enable FLL
    __bic_SR_register(SCG0);

    __delay_cycles(250000);

    // Loop until DCO stabilizes
    while(UCSCTL7 & DCOFFG)
    {
        //Clear OSC fault Flags
        UCSCTL7 &= ~(DCOFFG);

        //Clear OFIFG fault flag
        SFRIFG1 &= ~OFIFG;
    }

    UCSCTL5 &= ~(0x0007);   // Clear DIVM bits

#if (MCLK==1000000)

    UCSCTL5 |= DIVM_3 + DIVS_3;   // MCLK/8 = 1MHz; SMCLK/8 = 1MHz

#elif (MCLK==4000000)

    UCSCTL5 |= DIVM_1 + DIVS_1;   // MCLK/2 = 4MHz; SMCLK/2 = 4MHz

#elif (MCLK==8000000)
    __no_operation();   // No division required, MCLK = 8MHz

#else
#error "Please define a valid MCLK or add configuration"
#endif

}


/******************************************************************************
 *
 * @brief   Initializes the basic MCU HW
 *
 * @return  none
 *****************************************************************************/
inline static void HW_init(void)
{
    // Just initialize S2 button to force BSL mode
    P1OUT |= BIT1;
    P1REN |= BIT1;
    // The following routines disable interrupts which are cleared by POR but
    // not by a PUC. In F5529, these are: Timers, ADC12, DMA
#ifdef HW_RESET_PUC
    #ifdef __MSP430_HAS_T0A5__
        TA0CTL = 0x00;
    #endif
    #ifdef __MSP430_HAS_T1A3__
        TA1CTL = 0x00;
    #endif
    #ifdef __MSP430_HAS_T2A3__
        TA2CTL = 0x00;
    #endif
    #ifdef __MSP430_HAS_T0B7__
        TB0CTL = 0x00;
    #endif
    #ifdef __MSP430_HAS_ADC12_PLUS__
        ADC12CTL0 = 0x00;
    #endif
    #ifdef __MSP430_HAS_ADC10__
        ADC10CTL0 = 0x00;
    #endif
    #ifdef __MSP430_HAS_DMAX_3__
        DMA0CTL = 0x00;
        DMA1CTL = 0x00;
        DMA2CTL = 0x00;
    #endif

#endif
}
