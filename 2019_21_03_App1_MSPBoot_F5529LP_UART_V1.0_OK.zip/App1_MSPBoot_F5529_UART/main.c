/*
 * \file   main.c
 *
 * \brief  Sample application for F5529 using MSPBoot
 *      This example places application in the appropriate area
 *      of memory (check linker file) and shows how to use redirected 
 *      interrupts 
*/
/* --COPYRIGHT--,BSD
 * Copyright (c) 2012, Texas Instruments Incorporated
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * *  Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * *  Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 *
 * *  Neither the name of Texas Instruments Incorporated nor the names of
 *    its contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO,
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
 * PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS;
 * OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR
 * OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
 * EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 * --/COPYRIGHT--*/
#include "msp430.h"
#include <stdint.h>
#include "TI_MSPBoot_Mgr_Vectors.h"

#include <string.h>


/*
 * NOTE: Modify hal.h to select a specific evaluation board and customize for
 * your own board.
 */


// Global flags set by events


// Application globals


/******************************************************************************
 *
 * @brief   Main function
 *  This example application performs the following functions:
 *  - Toggle LED1 (P1.0) at startup (to indicate App1 execution)
 *  - Toggles LED1 using a timer periodic interrupt (demonstrates vector redirection)
 *  - Forces Boot mode when button S2 (P1.1) is pressed (demonstrates vector
 *      redirection and Boot Mode call
 *
 * @return  none
 *****************************************************************************/
/* --COPYRIGHT--,BSD
 * Copyright (c) 2016, Texas Instruments Incorporated
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * *  Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * *  Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 *
 * *  Neither the name of Texas Instruments Incorporated nor the names of
 *    its contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO,
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
 * PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS;
 * OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR
 * OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
 * EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 * --/COPYRIGHT--*/

/*

 * ======== main ========
 */
/*******************************************************************************
  * @File    : main.c
  * @Author  : Redouane Es-sadaoui <redouane.essadaoui@my-enova.com>, Arkeocean
  * @Brief   : UART API
  * @Tools   : IDE- Code composer studio v5.5, Target- MSP430F5529LP
  * @Date    : Last update, June 23, 2017
*******************************************************************************/

#define TXnotRX  0  //transmitter = 1, receiver = 0
#define loopBack

char myString[] =  {"hello I m Redouane"};
char *txData = myString;
char rxData[64];
char offsetTab = 0;
unsigned int i ;
int main(void)
{
  WDTCTL = WDTPW | WDTHOLD;                 // Stop WDT

         // seq indicator

                  P1OUT ^= (BIT0);
                  __delay_cycles(2500000);
                  P1OUT ^= (BIT0);
                  __delay_cycles(2500000);
                  P1OUT ^= (BIT0);
                  __delay_cycles(2500000);
                  P1OUT ^= (BIT0);P1OUT ^= (BIT0);
                  __delay_cycles(2500000);
                  P1OUT ^= (BIT0);
                  __delay_cycles(2500000);
                  P1OUT ^= (BIT0);
                  __delay_cycles(2500000);
                  P1OUT ^= (BIT0);

  // Set S1 (P2.1) as interrupt with internal pull-up
  P2OUT |= BIT1;
  P2REN |= BIT1;
  P2IES |= BIT1;
  P2IE |= BIT1;
  
// config uart

  P3SEL |= BIT3 | BIT4;                    // Assign P3.3 to UCA0TXD and...
  P3DIR |= BIT3;                           // P3.4 to UCA0RXD
  P1DIR |= 0x01;                  // configure P1.0 as output
  UCA0CTL1 |= UCSWRST;                      // **Put state machine in reset**

  UCA0CTL1 |= UCSSEL_1;                     // CLK = ACLK
  UCA0BR0 |= 0x03;                           // 0x0332kHz/9600=3.41 (see User's Guide)
  UCA0BR1 = 0x00;                           //
  UCA0MCTL = UCBRS_3|UCBRF_0;               // Modulation UCBRSx=3, UCBRFx=0

  UCA0CTL1 &= ~UCSWRST;                     // **Initialize USCI state machine**
  UCA0IE |= UCRXIE;                         // Enable USCI_A0 RX interrupt

 __enable_interrupt();

 UCA0TXBUF = 0xAB;               // TX -> RXed character

  while (1){


  }



}

// UART ISR
//ragma vector=USCI_A0_VECTOR
__interrupt void USCI_A0_ISR(void)

{
  switch(__even_in_range(UCA0IV, 4))
  {
  case 0:break;                             // Vector 0 - no interrupt
  case 2:                                   // Vector 2 - RXIFG
    while (!(UCA0IFG & UCTXIFG));           // wait for USCI_A0 TX buffer to ready
    rxData[offsetTab++] = UCA0RXBUF;
    P1OUT ^= 0x01;

 #ifdef loopBack
    // loop back
    UCA0TXBUF = UCA0RXBUF;                  // TX -> RXed character
 #endif

    break;
  case 4:break;                             // Vector 4 - TXIFG
  default: break;
  }
}





/******************************************************************************
 *
 * @brief   Timer A Interrupt service routine
 *  This routine simply toggles an LED but it shows how to declare interrupts
 *   in Application space
 *   Note that this function prototype should be accessible by 
 *   TI_MSPBoot_Mgr_Vectors.c and it should be declared in ProxyVectorTable
 *
 * @return  none
 *****************************************************************************/
__interrupt void Timer_A (void)
{
  P1OUT ^= BIT0;                            // Toggle P1.0
  TA0CCTL0 &= ~CCIFG;
 }

/******************************************************************************
 *
 * @brief   Port 1 Interrupt service routine
 *  Forces Boot mode when button S2 (P1.1) is pressed
 *   Note that this function prototype should be accessible by TI_MSPBoot_Mgr_Vectors.c
 *   and it should be declared in ProxyVectorTable
 *
 * @return  none
 *****************************************************************************/
__interrupt void P1_Isr(void)
{
    P1IFG = 0;
    TI_MSPBoot_JumpToBoot();
}

/******************************************************************************
 *
 * @brief   Dummy Interrupt service routine
 *  This ISR will be executed if an undeclared interrupt is called
 *
 * @return  none
 *****************************************************************************/
#pragma vector = unused_interrupts
__interrupt void Dummy_Isr(void)
{
    while(1)
        ;
}

