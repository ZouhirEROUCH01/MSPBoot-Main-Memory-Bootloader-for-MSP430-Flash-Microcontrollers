
//******************************************************************************
//   MSPBoot: MSP430F5529 Host using UART with MSP430F5529 Target
//
//   Description: Host follows BSL protocol to program a MSP430F5529 target
//   via UART using MSPBoot. Please refer to SLAA600 for more information
//   
//   Instructions:
//   1. Connect host and target as seen below
//   2. At startup, LED2 of the host will be ON
//   3. Press S2 on the Host to start transferring the first application image
//      a. LED1 on the host will blink at start of transfer, then remain on when 
//         complete
//      b. LED1 on the target will periodically blink when the first application 
//         has been programmed
//   4. Press S2 on the target to force it to enter MSPBoot code	
//      a. LED1 will stop blinking
//   5. Press S2 on the host to start transferring the second application image
//      a. LED1 on the host will blink at start of transfer, then remain off when 
//         complete
//      b. LED1 on the target will blink once when the image is successfully 
//         programmed
//   6. Press S1 on the target and LED2 will turn on and off
//   7. Press S2 on the host to repeat the process starting at step 1
//
//             MSP430F5529 (HOST)                  MSP430F5529 (TARGET)
//             ------------------                  ------------------
//      /|\   |                  |/|\          /|\|                  |   /|\
//       --o--|P2.1/S1           | |            | |           P2.1/S1|--o--
//      \|/   |               RST|--            --|RST               |   \|/
//            |                  |                |                  |
//      /|\   |                  |                |                  |   /|\
//       --o--|P1.1/S2           |                |           P1.1/S2|--o--
//      \|/   |                  |                |                  |   \|/
//            |                  |                |                  |
//     LED1<--|P1.0  P3.4/UCA0RXD|--------------->|P3.3/UCA0TXD  P1.0|-->LED1
//            |                  |                |                  |
//     LED2<--|P4.7  P3.3/UCA0TXD|<-------------->|P3.4/UCA0RXD  P4.7|-->LED2
//                                       
//	 Caleb Overbay
//   Texas Instruments Inc.
//   June 2017
//******************************************************************************

#include <msp430.h> 
#include <stdint.h>
#include <stdbool.h>
#include <stdio.h>
#include "bsl.h"

//
// Target Application files
// Contain the sample applications sent to the target
//
//TODO: Update the file name's if they were changed
#if (defined(SINGLE_IMAGE))
#include "TargetApps\App1_F5529_UART_Single_Image.h"
#include "TargetApps\App2_F5529_UART_Single_Image.h"
#elif  (defined(DUAL_IMAGE))
#include "TargetApps\App1_F5529_UART_Dual_Image.c"
#include "TargetApps\App2_F5529_UART_Dual_Image.c"
#else
#error Define a valid target
#endif

/* Statics */
static bool sentBSLFlipFlop;
static bool bPerformBSL;
static uint16_t CRC_Val1, CRC_Val2;

/*
* TODO: Update these values to match the values defined 
* in your target device's linker command file
*/
#if (defined(SINGLE_IMAGE))
static uint16_t CRC_Addr = 0x4400;					// (_Appl_Checksum in target's linker command file)
static uint16_t App_StartAddress = 0x4402;          // (_Appl_Start_Memory in target's linker command file)
static uint16_t App_EndAddress = 0xF7FF;            // (_Appl_End in in target's linker command file)
static uint32_t App_StartAddress_Upper = 0x10000;   // (_Flex_Start in target's linker command file)
static uint32_t App_EndAddress_Upper = 0x243FF;     // (_Flex_End in target's linker command file)
#elif (defined(DUAL_IMAGE))
static uint16_t CRC_Addr = 0x4400;
static uint16_t App_StartAddress = 0x4402;
static uint16_t App_EndAddress = 0xF3FF;
static uint32_t App_StartAddress_Upper = 0x10000;
static uint32_t App_EndAddress_Upper = 0x149FF;
#endif


/* Error Checking Macro */
#define CHECK_RESPONSE()  if(res != BSL_OK_RES)             \
{                                             \
    break;                                    \
}

static uint16_t Calc_App_CRC(uint32_t * Addr_array, uint32_t *Size_array, uint8_t ** DataPtr_Array, uint8_t num_arrays);

int main(void)
{
    uint8_t res;
    uint8_t section;

    /* Stop the watchdog timer */
    WDTCTL = WDTPW | WDTHOLD;

    // Set DCO = 8MHz

    UCSCTL3 &= ~(SELREF_7);     // Clear FLL Reference Select Bits
    UCSCTL3 |= SELREF_2;        // Set FLL Reference to REFOCLK
    UCSCTL4 |= SELA__VLOCLK;

    // Loop until DCO stabilizes
    while(UCSCTL7 & DCOFFG)
    {
        //Clear OSC fault Flags
        UCSCTL7 &= ~(DCOFFG);

        //Clear OFIFG fault flag
        SFRIFG1 &= ~OFIFG;
    }

    // Disable FLL
    __bis_SR_register(SCG0);

    UCSCTL2 &= ~(0x03FF);       // Clear FLLN Bits
    UCSCTL2 |= 249;             // Set DCO Multiplier for 8MHz
                                // (N + 1) * FLLRef = Fdco
                                // (249 + 1) * 32768 = 8MHz
    UCSCTL1 = DCORSEL_4;        // Set DCO range select

    // Re-enable FLL
    __bic_SR_register(SCG0);

    __delay_cycles(250000);

    UCSCTL5 &= ~(0x0007);   // Clear DIVM bits

    /* Calculate CRC for both applications */
    CRC_Val1 = Calc_App_CRC((uint32_t *)&App1_Addr[0],
                             (uint32_t *)&App1_Size[0],
                             (uint8_t **)&App1_Ptr[0],
                             sizeof(App1_Addr)/ sizeof (App1_Addr[0]));





    BSL_Init();

    /* Start P1.1 (S2 button) as interrupt with pull-up */
    P1OUT |= (BIT1);
    P1OUT &= ~BIT0;
    P1DIR |= BIT0;
    P1REN |= BIT1;
    P1IES |= BIT1;
    P1IFG &= ~BIT1;
    P1IE |= BIT1;
    //set P4.7 LED to show we are ready
    P4OUT |= BIT7;
    P4DIR |= BIT7;

   // bPerformBSL = true;
    __delay_cycles(2500000);
    __delay_cycles(2500000);
    __delay_cycles(2500000);
    __delay_cycles(2500000);
    __delay_cycles(2500000);
    while (1) {
        P1IFG &= ~BIT1; // Clear button flag before going to sleep
        __bis_SR_register(LPM0_bits + GIE);
        __disable_interrupt();

        while (bPerformBSL == true)  {

        	bPerformBSL = false;

            if (!BSL_slavePresent())
                break;
            /* Sending the BSL Entry command to user app on target */
            BSL_sendSingleByte(VBOOT_ENTRY_CMD);
            __delay_cycles(500000);

            BSL_flush();

            /* Sending the version command */
            res = BSL_sendCommand(BSL_VERSION_CMD);

            /* Making sure the version matches (only check upper nibble) */
            if ((res&0xF0) == (VBOOT_VERSION&0xF0))
            {
                /* Erasing the user application */
                res = BSL_sendCommand(BSL_ERASE_APP_CMD);
               CHECK_RESPONSE();


                /* Blinking LED to signal BSL start */
                P1OUT ^= (BIT0);
                __delay_cycles(2500000);
                P1OUT ^= (BIT0);
                __delay_cycles(2500000);
                P1OUT ^= (BIT0);
                __delay_cycles(2500000);
                P1OUT ^= (BIT0);

				for (section = 0; section < (sizeof(App1_Addr)/ sizeof (App1_Addr[0])) ; section++)
				{
					/* Sending the segments*/
					res = BSL_programMemorySegment((uint32_t)App1_Addr[section],
												   App1_Ptr[section], (uint32_t)App1_Size[section]);
					CHECK_RESPONSE();
				}
				/* Sending the CRC */
				//res = BSL_programMemorySegment(CRC_Addr,(uint8_t *) &CRC_Val1, 2);
				//CHECK_RESPONSE();

                __delay_cycles(2500000); // delay.

                /* Jumping to user code */
                res = BSL_sendCommand(BSL_JMP_APP_CMD);
                // End of cycle completed OK
                __delay_cycles(2500000);
                P1OUT ^= (BIT0);
                __delay_cycles(2500000);
                P1OUT ^= (BIT0);
                __delay_cycles(2500000);
                P1OUT ^= (BIT0);
            }

        }
    }
}

/* Push button that will invoke BSL send */
#pragma vector=PORT1_VECTOR
__interrupt void Port_1(void)
{
    P1IFG &= ~BIT1;
    bPerformBSL = true;
    __bic_SR_register_on_exit(LPM0_bits);
}

/* Calculate the CRC of the application*/
static uint16_t Calc_App_CRC(uint32_t * Addr_array, uint32_t *Size_array, uint8_t ** DataPtr_Array, uint8_t num_arrays)
{
    uint16_t addr;
    uint8_t i;
    CRCINIRES = 0xFFFF;

    // Calculate CRC for the whole Application address range
    for (addr=App_StartAddress; addr <= App_EndAddress; addr++)
    {
        for (i = 0; i < num_arrays; i ++)
        {
            // Check if address is defined by application image
            if ( (addr >= Addr_array[i]) &&
                 (addr < (Addr_array[i] + Size_array[i])) )
            {
                // If address is defined, add it to the CRC
            	CRCDIRB_L = DataPtr_Array[i][addr-Addr_array[i]];
                break;
            }
        }
        if (i==num_arrays)
        {
            // If not, simply add 0xFF
        	CRCDIRB_L = 0xFF;
        }
    }

    // CRC includes the upper Application address range
    uint32_t addr20;
    for (addr20=App_StartAddress_Upper; addr20 <= App_EndAddress_Upper; addr20++)
    {
        for (i = 0; i < num_arrays; i ++)
        {
            // Check if address is defined by application image
            if ( (addr20 >= Addr_array[i]) &&
                 (addr20 < (Addr_array[i] + Size_array[i])) )
            {
                // If address is defined, add it to the CRC
            	CRCDIRB_L = DataPtr_Array[i][addr20-Addr_array[i]];
                break;
            }
        }
        if (i==num_arrays)
        {
            // If not, simply add 0xFF
        	CRCDIRB_L = 0xFF;
        }
    }

    return CRCINIRES;
}
