
#include <stdint.h>
#include <msp430.h>

#include "bsl.h"

#define TIMEOUT_COUNT   6000000
#define BAUDRATE 9600

#if (BAUDRATE == 9600)
#       define UCOS16_VAL   1
#       define UCBRx_VAL    54
#       define UCBRSx_VAL   0
#       define UCBRFx_VAL   4
#elif (BAUDRATE == 115200)
#       define UCOS16_VAL   0
#       define UCBRx_VAL    72
#       define UCBRSx_VAL   3
#       define UCBRFx_VAL   0
#else
#       error "Baudrate is not supported"
#endif

void BSL_Comm_Init(void) {
	/* Initializing UART Module */
	UCA0CTLW0 = UCSWRST | UCSSEL_2;   // USCI held in reset and use SMCLK = 8MHz

    P3SEL |= (BIT3 | BIT4);                 // Enable P1[1:2] for USCI_A0 UART mode

    UCA0BR0 = (UCBRx_VAL & 0xFF);           // Set Low baudrate byte
    UCA0BR1 = (UCBRx_VAL >> 8);             // Set high baudrate byte
    UCA0MCTL = UCOS16_VAL |                 // Set modulation values
              (UCBRSx_VAL << 1) |
              (UCBRFx_VAL << 4) ;
    UCA0CTL1 &= ~UCSWRST;                   // Clear SW reset, resume operation
}

/* Reads one byte from BSL target */
uint8_t BSL_getResponse(void) {
	uint32_t timeout = TIMEOUT_COUNT;

	while ((!(UCA0IFG & UCRXIFG)) && (timeout-- > 0))
		;

	if (!timeout)
		return 0xFF;
	else
		return UCA0RXBUF;
}

/* Checks if a slave is responding */
uint8_t BSL_slavePresent(void) {
	// NO ACK in UART
	return 1;
}

/* Sends single UART Byte */
void BSL_sendSingleByte(uint8_t ui8Byte) {
	uint32_t timeout = TIMEOUT_COUNT;
	while ((!(UCA0IFG & UCTXIFG)) && (timeout-- > 0))
		;

	if (!timeout)
		return;
	else
		UCA0TXBUF = ui8Byte;
}

/* Sends application image to BSL target
 * This is a polling function and is blocking. */
void BSL_sendPacket(tBSLPacket tPacket) {
	uint16_t ii;
	volatile uint8_t crch, crcl;

	BSL_sendSingleByte(0x80);
	BSL_sendSingleByte(tPacket.ui8Length);
	BSL_sendSingleByte(tPacket.tPayload.ui8Command);

	if (tPacket.ui8Length > 1) {
		BSL_sendSingleByte(tPacket.tPayload.ui8Addr_L);
		BSL_sendSingleByte(tPacket.tPayload.ui8Addr_M);
		BSL_sendSingleByte(tPacket.tPayload.ui8Addr_H);
        for (ii = 0; ii < (tPacket.ui8Length - 4); ii++) {
            BSL_sendSingleByte(tPacket.tPayload.ui8pData[ii]);
        }

	}

	crcl = (uint8_t) (tPacket.ui16Checksum & 0xFF);
	BSL_sendSingleByte(crcl);

	crch = (uint8_t) (tPacket.ui16Checksum >> 8);
	BSL_sendSingleByte(crch);

}

void BSL_flush(void) {
	UCA0IFG &= ~(UCRXIFG);
}
